package com.example.android.model;
import java.util.List;

public class Review {


    private int id;
    private String commentTitle;
    private String commentBody;

    private User user;
    private OrderItem order;
    private List<Review> reviewReply;
    private Review parentReview;

    public Review(String commentTitle, String commentBody, User user, OrderItem order, Review parentReview) {
        this.commentTitle = commentTitle;
        this.commentBody = commentBody;
        this.user = user;
        this.order = order;
        this.parentReview = parentReview;
    }
}