package com.example.android.model;


import java.time.LocalDate;
import java.util.List;

public class Cart {
    private int id;
    private LocalDate dateCreated;
}