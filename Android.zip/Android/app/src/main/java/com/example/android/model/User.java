package com.example.android.model;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class User implements Serializable {
    int id;
    String login;
    String password;
    LocalDate birthDate;
    String name;
    String surname;
    private String type;
    private String address;
    private String cardNo;
    List<Comment> myComments;
    private Cart myCart;
    private Warehouse warehouse;
    private boolean isAdmin;
    private List<Review> myReviews;
    public User(String login, String password, LocalDate birthDate, String name, String surname, String type, String address, String cardNo, Warehouse warehouse){
        this.login = login;
        this.password = password;
        this.birthDate = birthDate;
        this.name = name;
        this.surname = surname;
        this.type = type;
        this.address = address;
        this.cardNo = cardNo;
        this.warehouse = warehouse;
    }

    public User(int id, String login, String password, LocalDate birthDate) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.birthDate = birthDate;
    }

    @Override
    public String toString() {
        return type+ " " + name + " " + surname;
    }

    public LocalDate getBday() {
        return birthDate;
    }

    public int getId() {
        return id;
    }
    public void setBday(LocalDate value) {
        this.birthDate = birthDate;
    }
}
