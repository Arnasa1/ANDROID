package com.example.android;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.android.helpers.Rest;
import com.example.android.model.Product;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static com.example.android.helpers.Constants.*;

public class MyAccountActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account);

        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        TextView name = findViewById(R.id.accountName);
        TextView pass = findViewById(R.id.accountPassword);

        executor.execute(()->{
            try {
                String response = Rest.sendGet(VALIDATE_USER);
                handler.post(()->{
                    try{
                        if(!response.equals("Error")){

                            Gson productsGson = new Gson();
                            String message = getIntent().getStringExtra(ProductsActivity.response);
                            name.setText(message);
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    };
    public void back (View view)
    {
        setContentView(R.layout.activity_products);
    }
    public void updateUser  (View view)
    {
        TextView login = findViewById(R.id.accountName);
        TextView psw = findViewById(R.id.accountPassword);
        //GsonBuilder build = new GsonBuilder();
        Gson gson = new Gson();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("login",login.getText().toString());
        jsonObject.addProperty("password",psw.getText().toString());
        String info = gson.toJson(jsonObject);
        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(()->{
            try {
                String response = Rest.sendPut(UPDATE_USER, info);
                handler.post(()->{
                    try{
                        if(!response.equals("Error")){

                            Gson productsGson = new Gson();
                            String message = getIntent().getStringExtra(ProductsActivity.response);
                            //name.setText(message);
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}
