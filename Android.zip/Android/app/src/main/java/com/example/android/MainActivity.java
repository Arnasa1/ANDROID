package com.example.android;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.android.helpers.Rest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static com.example.android.helpers.Constants.VALIDATE_USER;

public class MainActivity extends AppCompatActivity{

    public static String response;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void validateuser(View view){
        TextView login = findViewById(R.id.loginField);
        TextView psw = findViewById(R.id.pswField);
        //GsonBuilder build = new GsonBuilder();
        Gson gson = new Gson();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("login",login.getText().toString());
        jsonObject.addProperty("password",psw.getText().toString());
        String info = gson.toJson(jsonObject);

        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(()->{
            try {
                String response = Rest.sendPost(VALIDATE_USER, info);
                handler.post(()->{
                    try{
                        if(!response.equals("Error")){
                            Intent intent = new Intent(MainActivity.this, ProductsActivity.class);
                            intent.putExtra("userObject", response);
                            startActivity(intent);
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

}