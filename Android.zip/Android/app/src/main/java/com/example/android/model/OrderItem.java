package com.example.android.model;


import java.time.LocalDate;
import java.util.List;

public class OrderItem {
    private int id;
    private Cart cart;
    private LocalDate dateCreated;;
    public String orderStatus;

    public OrderItem(Cart cart, LocalDate dateCreated, String orderStatus) {
        this.cart = cart;
        this.dateCreated = dateCreated;
        this.orderStatus = orderStatus;
    }

}
