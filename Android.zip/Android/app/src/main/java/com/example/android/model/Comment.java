package com.example.android.model;
import java.util.List;


public class Comment {

    private int id;
    private String commentTitle;
    private String commentBody;


    public Comment(String commentTitle, String commentBody, User user, Product product, Comment parentComment) {
        this.commentTitle = commentTitle;
        this.commentBody = commentBody;

    }
}