package com.example.android.model;


import java.io.Serializable;
import java.util.List;


public class Product implements Serializable {

    int id;
String title;
String description;
String manufacturer;
int price;
String type;
Cart cart;
Warehouse warehouse;
List<Comment> comments;




  public Product(String title, String description, String manufacturer, String type, int price, Warehouse warehouse) {
    this.title = title;
    this.description = description;
    this.manufacturer = manufacturer;
    this.type = type;
    this.price = price;
    this.warehouse = warehouse;
  }
  public String toString() {
    return "Title:" + title + " Description: " + description + " Manufacturer: " + manufacturer + " Type: " + type + " Price: " + price;
  }



}
