package com.example.android.helpers;

public class Constants {
    public static final String BASE_URL = "http://192.168.1.67:8080";
    public static final String VALIDATE_USER = BASE_URL + "/user/getUserByCredentials";
    public static final String GET_PRODUCTS = BASE_URL + "/product/getAllProducts";
    public static final String UPDATE_USER = BASE_URL + "/user/updateUser";
    public static final String GET_USER = BASE_URL + "/getUserById/";
}
