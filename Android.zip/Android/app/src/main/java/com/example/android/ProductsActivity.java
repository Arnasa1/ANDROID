package com.example.android;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.example.android.helpers.Rest;
import com.example.android.model.Product;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static com.example.android.helpers.Constants.GET_PRODUCTS;
import static com.example.android.helpers.Constants.VALIDATE_USER;

public class ProductsActivity extends AppCompatActivity {

    public static String response;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(()->{
            try {
                String response = Rest.sendGet(GET_PRODUCTS);
                handler.post(()->{
                    try{
                        if(!response.equals("Error")){

                            Gson productsGson = new Gson();

                            Type productListType = new TypeToken<List<Product>>(){
                            }.getType();

                            List<Product> list = productsGson.fromJson(response, productListType);


                            ListView productListElement = findViewById(R.id.productListElement);

                            ArrayAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
                            productListElement.setAdapter(adapter);
                            productListElement.setOnItemClickListener((parent,view,position,id) ->{

                            });
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


    }
    public void viewMyAccount (View view) throws IOException {
        Intent intent = new Intent(ProductsActivity.this, MyAccountActivity.class);


    }
    public void viewMyCart (View view) throws IOException {
        Intent intent = new Intent(ProductsActivity.this, MyCart.class);
    }

}